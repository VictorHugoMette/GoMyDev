package GoMyDev;

/**
 * @author Victor
 */
public class Alunos {
    private String Sobrenome;
    private String Nome;
    private Departamento Dep;

    public Alunos() {
    }

    public Alunos(String Nome, String Sobrenome) {
        this.Nome = Nome;
        this.Sobrenome = Sobrenome;
    }

    public String getSobrenome() {
        return Sobrenome;
    }

    public void setSobrenome(String Sobrenome) {
        this.Sobrenome = Sobrenome;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public Departamento getDep() {
        return Dep;
    }

    public void setDep(Departamento Dep) {
        this.Dep = Dep;
    }
    
    
}
