package GoMyDev;

import java.util.ArrayList;

/**
 * @author Victor
 */
public class Departamento {
    private int Capacidade;
    private String Nome;
    ArrayList<Alunos> ListaUser;

    public Departamento() {
        ListaUser = new ArrayList();
    }

    public Departamento(int Capacidade, String Nome) {
        this.Capacidade = Capacidade;
        this.Nome = Nome;
        ListaUser = new ArrayList();
    }

    public int getCapacidade() {
        return Capacidade;
    }

    public void setCapacidade(int Capacidade) {
        this.Capacidade = Capacidade;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public ArrayList<Alunos> getListaUser() {
        return ListaUser;
    }

    public void setListaUser(ArrayList<Alunos> ListaUser) {
        this.ListaUser = ListaUser;
    }
    
    public void addUser(Alunos F){
        F.setDep(this);
        ListaUser.add(F);
    }
}
